# Smart Trader AI
A secure AI-powered financial forecasting app using Streamlit, Firebase Auth, and LSTM models.

## Features
- Secure login (Google, Email OTP, optional Biometrics)
- Real-time stock/crypto predictions
- RSI, MACD, EMA, Bollinger, Volume analysis
- Deployed using Streamlit Cloud
